# bloxflip.py
Next gen bloxflip API wrapper, remake of original bloxflip.py
